This is the software specially made for the study:
"Preverbal infant expect supernatural agents to be socially dominant".
You will be recommended to read the original paper, before looking into this explanation file.
(If you wish to use for other purpose, you can either adjust the source file or use the simpler version https://github.com/YNakawake/timewatcher_others)

The software is coded by Visual Basic (Visual Studio 2017: https://docs.microsoft.com/ja-jp/visualstudio/releasenotes/vs2017-relnotes)
The source file is uploaded as "TimeWarcher_Source.exe" (https://github.com/YNakawake/timewatcher_socdominance/blob/master/TimeWatcher_Source.zip), you will be required to install Visual Studio to open and read the code.


Requirements
 - Two coders
 - Windows PC (I recommend Windows 10)

How to use:

Preparation before the experiment
1. Check your Input Mode is English
2. Double-click the "timewatcher.exe" to open the file
2. Insert ID into the textbox, next to the label written ?gParticipant ID?h (and also recommended to put the name of the coder/coders)
3. Click the radio button, if the experiment is of ?gobject continuity.?h (i.e. if the experiment is of ?ggravity?h, do not click)
4. Click the button written ?gSet?h, then the programme starts to count the time


During the experiment
Warm-up test
1. The keyboard is handed to the first coder.
2. Press 'Q' (on your keyboard), when 'warm-up trial' start
3. Press 'X' while the participant is looking away from the screen. In the left white textbox, cumulative looking time (of looking away from the screen) is presented. The cumulative time is reset if you press 'M'.

First four familiarization trials (two trials for the natural agent and two trials for the supernatural agent): every participant watch
1. Press 'Q' when the familiarization trial start
2. Press 'X' while the participant is looking away from the screen. 
3. Press 'M' when the new familiarization trial start


From the 5th familiarization, the trials will be terminated if participants look away consecutively 2 seconds and go to the test trials
1. Press 'P' when the 5th familiarization trial (3rd trial of the natural agent) start
2. Press 'M' while the participant looking away, if it exceeds 2s, the screen turned into the red (the time is displayed on the right white textbox).
3. If it exceeds 2s notify the experimenter to go to the test trial, and hand keyboard to the second coder. 
    If not the time is automatically reset, once you stop pushing.
4. If the participant did not look away for consecutively 2s and all 8 familiarisation trials finish, hand keyboard to the second coder.

Test trials
1. Press 'Q' to start
2. Press 'M' while the participant looking away, if it exceeds 2s, the screen turned into the red
3. If it exceeds 2s notify the experimenter to go to the second test trial.
4. Press 'W' when the second test trial starts.
5. Press 'M' while the participant looking away, if it exceeds 2s, the screen turned into the red
6. If it exceeds 2s notify the experimenter, notify the experimenter that experiment has finished.
7. Press 'Q' 

End
1. Close the window with Alt+F4
2. The log file is inside the Out folder in 'txt' format (each line shows: the key, the length of the time that the key has been pushed (only for 'X' and 'M'), the time point in which the key pushed (elapsed time from the beginning)
While this log file can be kept, I strongly recommend offline coding for data analyses.

If the file does not open, I recommend downloading Visual Studio 2017.
If you have any questions, please send an e-mail to the following address: yo.nakawake@anthro.ox.ac.uk

