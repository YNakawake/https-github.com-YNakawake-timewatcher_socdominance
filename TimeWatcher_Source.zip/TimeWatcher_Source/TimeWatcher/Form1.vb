﻿'Imports System.Media
'Imports System
Public Class Form1
    Public BeepTeller As Integer
    Public Tone1 As String
    Public ID As String
    Public FileName As String
    Public ElapsedFami As TimeSpan
    Dim TimeStump As Integer

    Dim StopWatch As New Diagnostics.Stopwatch
    Dim StopWatch2 As New Diagnostics.Stopwatch
    Dim StopWatchFami As New Diagnostics.Stopwatch  ' Familiarisation
    Dim OutFileName As String
    Dim switch As Integer


    Public PushedKey As Integer

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim elapsed As TimeSpan = Me.StopWatch.Elapsed

        TestLabel.Text = String.Format("{0:00}:{1:00}:{2:00}:{3:00}", Math.Floor(elapsed.TotalHours), elapsed.Minutes, elapsed.Seconds, elapsed.Milliseconds)


        If elapsed.Seconds = 60 Then
            TestLabel.ForeColor = Color.Red

            Me.BackColor = Color.Red

        ElseIf elapsed.Seconds > 60 Then

            TestLabel.ForeColor = Color.Red

        Else
            Me.BackColor = Color.Green
        End If



        ' System.Media.SystemSounds.Beep.Play()
        '   SystemSounds.Beep.Play()
    End Sub


    Private Sub TimerFami_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerFami.Tick

        ElapsedFami = Me.StopWatchFami.Elapsed
        FamiLabel.Text = String.Format("{0:00}:{1:00}:{2:00}:{3:00}", Math.Floor(ElapsedFami.TotalHours), ElapsedFami.Minutes, ElapsedFami.Seconds, ElapsedFami.Milliseconds)



        If ElapsedFami.Seconds = 10 Then
            TestLabel.ForeColor = Color.DarkCyan

            Me.BackColor = Color.DarkCyan

            If TimeStump = 2 Then
                TimeStump = TimeStump + 1
                Fami1.BackColor = Color.DarkRed
                Fami2.BackColor = Color.Tomato
                FileOpen(10, OutFileName, OpenMode.Append)
                Write(10, "A")
                Write(10, TimeStump)
                WriteLine(10, MasterTime.Text)
                FileClose(10)
                ListBox1.Items.Add("A" & "  [" & MasterTime.Text & "]")
            End If



        ElseIf ElapsedFami.Seconds > 10 Then

                TestLabel.ForeColor = Color.DarkCyan
                Me.BackColor = Color.DarkCyan

            Else
                Me.BackColor = Color.LightCyan
        End If



        ' System.Media.SystemSounds.Beep.Play()
        '   SystemSounds.Beep.Play()
    End Sub








    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Timer2.Start()
        Dim Cond As String
        Dim PerticipantID As String
        Dim NowTime As String
        NowTime = Format(Now, "yyyyMMddhhmmss")
        PerticipantID = TextBox1.Text

        If RadioButton1.Checked = True Then
            Cond = "1,Continuity"
        Else

            Cond = "0,Support"
        End If
        ListBox1.Items.Add(PerticipantID)
        ListBox1.Items.Add(Cond)
        RadioButton1.Enabled = False
        TextBox1.Enabled = False
        Button1.Enabled = False

        OutFileName = "Out/" & Format(Now, "yyyyMMddhhmmss") & "ID" & PerticipantID & "_" & Cond & ".txt"
        FileOpen(10, OutFileName, OpenMode.Output)
        Write(10, NowTime)
        Write(10, PerticipantID)
        WriteLine(10, Cond)
        FileClose(10)
        switch = 1

    End Sub

    '  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
    '    Timer1.Stop()
    'Me.StopWatch.Stop()
    ' End Sub

    ' Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
    'Me.StopWatch.Reset()
    '  Label1.Text = "00:00:00:000"
    '   ListBox1.Items.Clear()
    ' End Sub

    ' Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
    '    ListBox1.Items.Add(Label1.Text)
    ' End Sub

    'Private Sub Form1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles MyBase.KeyPress
    '    Timer1.Start()
    '    Me.StopWatch.Start()
    'End Sub

    'Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
    '    Timer1.Stop()
    '    Me.StopWatch.Stop()
    '    ListBox1.Items.Add(Label1.Text)
    '    ListBox2.Items.Add(Label2.Text)
    'End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Focus()
        'Timer2.Start()
        Me.StopWatch2.Start()
        'Tone1 = "C:\Users\Devlab24_PC2\source\repos\WindowsApp1\WindowsApp1\Tone\D3.wav"

        Me.KeyPreview = True

    End Sub

    'Private Sub Button1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Button1.KeyPress
    '    Timer1.Start()
    '    Me.StopWatch.Start()

    'End Sub

    'Private Sub Button1_KeyUp(sender As Object, e As KeyEventArgs) Handles Button1.KeyUp
    '    Timer1.Stop()
    '    Me.StopWatch.Stop()
    '    ListBox1.Items.Add(TestLabel.Text & "  [" & Label2.Text & "]")
    '    TestLabel.ForeColor = Color.Black
    '    BeepTeller = 0
    '    Me.BackColor = Color.White
    '    TestLabel.Text = "00:00:00:000"
    '    Me.StopWatch.Reset()
    'End Sub



    Private Sub Form1_KeyDown(ByVal sender As Object,
        ByVal e As System.Windows.Forms.KeyEventArgs) _
        Handles MyBase.KeyDown

        If switch = 1 Then
            '受け取ったキーを表示する
            ' Console.WriteLine(e.KeyCode)
            ' ListBox1.Items.Add(e.KeyCode)
            If e.KeyCode = Keys.X Then
                ' ListBox1.Items.Add(e.KeyCode)
                TimerFami.Start()
                Me.StopWatchFami.Start()

                ' FamiLabel.Text = String.Format("{0:00}:{1:00}:{2:00}:{3:00}", Math.Floor(ElapsedFami.TotalHours), ElapsedFami.Minutes, ElapsedFami.Seconds, ElapsedFami.Milliseconds)

            ElseIf e.KeyCode = Keys.M Then
                Timer1.Start()
                Me.StopWatch.Start()

                Me.StopWatchFami.Reset()

            End If

            If e.KeyCode = Keys.Q Then

                If TimeStump < 2 Then
                    TimeStump = TimeStump + 1
                    If TimeStump = 1 Then
                        Timer2.Start()
                        Pre.BackColor = Color.Tomato
                        FileOpen(10, OutFileName, OpenMode.Append)
                        Write(10, "Q")
                        Write(10, TimeStump)
                        WriteLine(10, "00:00:00:000")
                        FileClose(10)
                        ListBox1.Items.Add("Q" & TimeStump & "  [" & "00:00:00:000" & "]")
                    ElseIf TimeStump = 2 Then
                        Pre.BackColor = Color.DarkRed
                        Fami1.BackColor = Color.Tomato
                        FileOpen(10, OutFileName, OpenMode.Append)
                        Write(10, "Q")
                        Write(10, TimeStump)
                        WriteLine(10, MasterTime.Text)
                        FileClose(10)
                        ListBox1.Items.Add("Q" & TimeStump & "  [" & MasterTime.Text & "]")
                        Me.StopWatchFami.Reset()
                        FamiLabel.Text = "00:00:00:000"
                    End If
                ElseIf TimeStump > 2 Then
                    TimeStump = TimeStump + 1
                    If TimeStump = 4 Then
                        Fami2.BackColor = Color.DarkRed
                        Test1.BackColor = Color.Tomato
                        FileOpen(10, OutFileName, OpenMode.Append)
                        Write(10, "Q")
                        Write(10, TimeStump)
                        WriteLine(10, MasterTime.Text)
                        FileClose(10)
                        ListBox1.Items.Add("Q" & TimeStump & "  [" & MasterTime.Text & "]")
                    ElseIf TimeStump = 5 Then
                        Test1.BackColor = Color.DarkRed
                        Test2.BackColor = Color.Tomato
                        FileOpen(10, OutFileName, OpenMode.Append)
                        Write(10, "Q")
                        Write(10, TimeStump)
                        WriteLine(10, MasterTime.Text)
                        FileClose(10)
                        ListBox1.Items.Add("Q" & TimeStump & "  [" & MasterTime.Text & "]")
                    ElseIf TimeStump = 6 Then
                        FileOpen(10, OutFileName, OpenMode.Append)
                        Test2.BackColor = Color.DarkRed
                        Write(10, "Q")
                        Write(10, TimeStump)
                        WriteLine(10, MasterTime.Text)

                        FileClose(10)
                        ListBox1.Items.Add("Q" & TimeStump & "  [" & MasterTime.Text & "]")
                    End If
                End If
            End If


            If e.KeyCode = Keys.W Then
                FileOpen(10, OutFileName, OpenMode.Append)

                Write(10, "W")
                Write(10, "0")
                WriteLine(10, MasterTime.Text)
                ListBox1.Items.Add("W" & " [" & MasterTime.Text & "]")
                FileClose(10)
            End If


        End If

    End Sub
    Private Sub Form1_KeyUp(ByVal sender As Object,
        ByVal e As System.Windows.Forms.KeyEventArgs) _
        Handles MyBase.KeyUp
        '受け取ったキーを表示する
        ' Console.WriteLine(e.KeyCode)
        ' ListBox1.Items.Add(e.KeyCode)
        If switch = 1 Then
            If e.KeyCode = Keys.X Then
                Me.StopWatchFami.Stop()
                TimerFami.Stop()
                Me.BackColor = Color.White
                FileOpen(10, OutFileName, OpenMode.Append)
                Write(10, "X")
                Write(10, FamiLabel.Text)
                WriteLine(10, MasterTime.Text)

                FileClose(10)
                ListBox1.Items.Add("X" & FamiLabel.Text & "  [" & MasterTime.Text & "]")

            ElseIf e.KeyCode = Keys.M Then
                Timer1.Stop()
                Me.StopWatch.Stop()
                FileOpen(10, OutFileName, OpenMode.Append)
                Write(10, "M")
                Write(10, TestLabel.Text)
                WriteLine(10, MasterTime.Text)

                FileClose(10)

                ListBox1.Items.Add("M" & TestLabel.Text & "  [" & MasterTime.Text & "]")
                TestLabel.ForeColor = Color.Black
                BeepTeller = 0
                Me.BackColor = Color.White
                TestLabel.Text = "00:00:00:000"
                Me.StopWatch.Reset()

            End If

        End If

    End Sub





    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Button1.Focus()
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Dim elapsed2 As TimeSpan = Me.StopWatch2.Elapsed
        MasterTime.Text = String.Format("{0:00}:{1:00}:{2:00}:{3:00}", Math.Floor(elapsed2.TotalHours), elapsed2.Minutes, elapsed2.Seconds, elapsed2.Milliseconds)
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Pre_Click(sender As Object, e As EventArgs) Handles Pre.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub
End Class