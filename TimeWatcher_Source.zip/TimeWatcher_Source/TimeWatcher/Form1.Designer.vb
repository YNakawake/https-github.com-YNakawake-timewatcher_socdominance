﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TestLabel = New System.Windows.Forms.Label()
        Me.MasterTime = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.arrow5 = New System.Windows.Forms.Label()
        Me.arrow4 = New System.Windows.Forms.Label()
        Me.arrow3 = New System.Windows.Forms.Label()
        Me.arrow1 = New System.Windows.Forms.Label()
        Me.arrow2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Pre = New System.Windows.Forms.Label()
        Me.Test2 = New System.Windows.Forms.Label()
        Me.Test1 = New System.Windows.Forms.Label()
        Me.Fami2 = New System.Windows.Forms.Label()
        Me.Fami1 = New System.Windows.Forms.Label()
        Me.FamiLabel = New System.Windows.Forms.Label()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.TimerFami = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 50
        '
        'TestLabel
        '
        Me.TestLabel.BackColor = System.Drawing.Color.White
        Me.TestLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TestLabel.Font = New System.Drawing.Font("MS UI Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TestLabel.Location = New System.Drawing.Point(550, 262)
        Me.TestLabel.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.TestLabel.Name = "TestLabel"
        Me.TestLabel.Size = New System.Drawing.Size(360, 68)
        Me.TestLabel.TabIndex = 0
        '
        'MasterTime
        '
        Me.MasterTime.AutoSize = True
        Me.MasterTime.Location = New System.Drawing.Point(1729, 1224)
        Me.MasterTime.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.MasterTime.Name = "MasterTime"
        Me.MasterTime.Size = New System.Drawing.Size(116, 24)
        Me.MasterTime.TabIndex = 1
        Me.MasterTime.Text = "PressStart"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1606, 100)
        Me.Button1.Margin = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(163, 124)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Set"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(598, 900)
        Me.Button2.Margin = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(163, 46)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "stop"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(598, 988)
        Me.Button3.Margin = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(163, 46)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "mark"
        Me.Button3.UseVisualStyleBackColor = True
        Me.Button3.Visible = False
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(598, 1094)
        Me.Button4.Margin = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(163, 46)
        Me.Button4.TabIndex = 5
        Me.Button4.Text = "reset"
        Me.Button4.UseVisualStyleBackColor = True
        Me.Button4.Visible = False
        '
        'ListBox1
        '
        Me.ListBox1.AllowDrop = True
        Me.ListBox1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.ListBox1.ItemHeight = 24
        Me.ListBox1.Location = New System.Drawing.Point(1103, 242)
        Me.ListBox1.Margin = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.ScrollAlwaysVisible = True
        Me.ListBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
        Me.ListBox1.Size = New System.Drawing.Size(375, 1060)
        Me.ListBox1.TabIndex = 6
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Controls.Add(Me.arrow5)
        Me.GroupBox1.Controls.Add(Me.arrow4)
        Me.GroupBox1.Controls.Add(Me.arrow3)
        Me.GroupBox1.Controls.Add(Me.arrow1)
        Me.GroupBox1.Controls.Add(Me.arrow2)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Pre)
        Me.GroupBox1.Controls.Add(Me.Test2)
        Me.GroupBox1.Controls.Add(Me.Test1)
        Me.GroupBox1.Controls.Add(Me.Fami2)
        Me.GroupBox1.Controls.Add(Me.Fami1)
        Me.GroupBox1.Controls.Add(Me.FamiLabel)
        Me.GroupBox1.Controls.Add(Me.ListBox1)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.MasterTime)
        Me.GroupBox1.Controls.Add(Me.TestLabel)
        Me.GroupBox1.Location = New System.Drawing.Point(167, 80)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.GroupBox1.Size = New System.Drawing.Size(1993, 1330)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(1146, 40)
        Me.Label1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 24)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Perticipant ID"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(1343, 34)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(268, 31)
        Me.TextBox1.TabIndex = 22
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(1629, 36)
        Me.RadioButton1.Margin = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(202, 28)
        Me.RadioButton1.TabIndex = 21
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Continuity: Yes?"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'arrow5
        '
        Me.arrow5.AutoSize = True
        Me.arrow5.BackColor = System.Drawing.Color.Transparent
        Me.arrow5.Location = New System.Drawing.Point(715, 88)
        Me.arrow5.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.arrow5.Name = "arrow5"
        Me.arrow5.Size = New System.Drawing.Size(87, 24)
        Me.arrow5.TabIndex = 20
        Me.arrow5.Text = "--Q-->"
        '
        'arrow4
        '
        Me.arrow4.AutoSize = True
        Me.arrow4.BackColor = System.Drawing.Color.Transparent
        Me.arrow4.Location = New System.Drawing.Point(546, 88)
        Me.arrow4.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.arrow4.Name = "arrow4"
        Me.arrow4.Size = New System.Drawing.Size(87, 24)
        Me.arrow4.TabIndex = 19
        Me.arrow4.Text = "--Q-->"
        '
        'arrow3
        '
        Me.arrow3.AutoSize = True
        Me.arrow3.BackColor = System.Drawing.Color.Transparent
        Me.arrow3.Location = New System.Drawing.Point(373, 88)
        Me.arrow3.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.arrow3.Name = "arrow3"
        Me.arrow3.Size = New System.Drawing.Size(85, 24)
        Me.arrow3.TabIndex = 18
        Me.arrow3.Text = "--P-->"
        '
        'arrow1
        '
        Me.arrow1.AutoSize = True
        Me.arrow1.BackColor = System.Drawing.Color.Transparent
        Me.arrow1.Location = New System.Drawing.Point(33, 88)
        Me.arrow1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.arrow1.Name = "arrow1"
        Me.arrow1.Size = New System.Drawing.Size(87, 24)
        Me.arrow1.TabIndex = 17
        Me.arrow1.Text = "--Q-->"
        '
        'arrow2
        '
        Me.arrow2.AutoSize = True
        Me.arrow2.Location = New System.Drawing.Point(191, 88)
        Me.arrow2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.arrow2.Name = "arrow2"
        Me.arrow2.Size = New System.Drawing.Size(87, 24)
        Me.arrow2.TabIndex = 16
        Me.arrow2.Text = "--Q-->"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(715, 150)
        Me.Label4.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(0, 24)
        Me.Label4.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(524, 150)
        Me.Label3.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 24)
        Me.Label3.TabIndex = 14
        '
        'Pre
        '
        Me.Pre.BackColor = System.Drawing.Color.MistyRose
        Me.Pre.Location = New System.Drawing.Point(102, 30)
        Me.Pre.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Pre.Name = "Pre"
        Me.Pre.Size = New System.Drawing.Size(106, 102)
        Me.Pre.TabIndex = 12
        Me.Pre.Text = "Pre"
        '
        'Test2
        '
        Me.Test2.BackColor = System.Drawing.Color.MistyRose
        Me.Test2.Location = New System.Drawing.Point(787, 30)
        Me.Test2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Test2.Name = "Test2"
        Me.Test2.Size = New System.Drawing.Size(102, 102)
        Me.Test2.TabIndex = 11
        Me.Test2.Text = "Test2"
        '
        'Test1
        '
        Me.Test1.BackColor = System.Drawing.Color.MistyRose
        Me.Test1.Location = New System.Drawing.Point(624, 30)
        Me.Test1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Test1.Name = "Test1"
        Me.Test1.Size = New System.Drawing.Size(102, 102)
        Me.Test1.TabIndex = 10
        Me.Test1.Text = "Test1"
        '
        'Fami2
        '
        Me.Fami2.BackColor = System.Drawing.Color.MistyRose
        Me.Fami2.Location = New System.Drawing.Point(455, 30)
        Me.Fami2.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Fami2.Name = "Fami2"
        Me.Fami2.Size = New System.Drawing.Size(102, 102)
        Me.Fami2.TabIndex = 9
        Me.Fami2.Text = "Fami-2"
        '
        'Fami1
        '
        Me.Fami1.BackColor = System.Drawing.Color.MistyRose
        Me.Fami1.Location = New System.Drawing.Point(273, 30)
        Me.Fami1.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.Fami1.Name = "Fami1"
        Me.Fami1.Size = New System.Drawing.Size(106, 102)
        Me.Fami1.TabIndex = 8
        Me.Fami1.Text = "Fam-1"
        '
        'FamiLabel
        '
        Me.FamiLabel.BackColor = System.Drawing.Color.White
        Me.FamiLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.FamiLabel.Font = New System.Drawing.Font("MS UI Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FamiLabel.Location = New System.Drawing.Point(106, 262)
        Me.FamiLabel.Margin = New System.Windows.Forms.Padding(7, 0, 7, 0)
        Me.FamiLabel.Name = "FamiLabel"
        Me.FamiLabel.Size = New System.Drawing.Size(360, 68)
        Me.FamiLabel.TabIndex = 7
        '
        'Timer2
        '
        Me.Timer2.Interval = 50
        '
        'TimerFami
        '
        Me.TimerFami.Interval = 50
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(2340, 1434)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(7, 6, 7, 6)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As Timer
    Friend WithEvents TestLabel As Label
    Friend WithEvents MasterTime As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents FamiLabel As Label
    Friend WithEvents TimerFami As Timer
    Friend WithEvents Fami1 As Label
    Friend WithEvents Fami2 As Label
    Friend WithEvents Test2 As Label
    Friend WithEvents Test1 As Label
    Friend WithEvents Pre As Label
    Friend WithEvents arrow2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents arrow3 As Label
    Friend WithEvents arrow1 As Label
    Friend WithEvents arrow5 As Label
    Friend WithEvents arrow4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents RadioButton1 As RadioButton
End Class
